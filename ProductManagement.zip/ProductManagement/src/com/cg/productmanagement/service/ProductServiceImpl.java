package com.cg.productmanagement.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.productmanagement.dao.IProductDao;
import com.cg.productmanagement.dao.ProductDaoImpl;
import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exception.ProductException;


public class ProductServiceImpl implements IProductService {
    IProductDao prodDao;
	public ProductServiceImpl() throws ProductException {
    prodDao=new ProductDaoImpl();
	}

	@Override
	public int addProduct(Product p) throws ProductException, SQLException {

		return prodDao.addProduct(p) ;
	}

	@Override
	public List<Product> showAll() throws ProductException {

		return prodDao.showAll();
	}

	@Override
	public Product getProduct(int productid) {

		return prodDao.getProduct(productid);
	}

	@Override
	public boolean updateQty(int productid, String productname,
			String productdesc, int productqty, int productprice)
			throws ProductException {

		return prodDao.updateQty(productid, productname, productdesc, productqty, productprice);
	}

	@Override
	public int deleteProduct(int productId) throws ProductException {

		return prodDao.deleteProduct(productId);
	}
	
	public List<String> isValidated(Product p) {
		List<String> errorList = new ArrayList<String>();

		Pattern pattern = null;
		Matcher matcher = null;

		// Product Name Validation
		pattern = Pattern.compile("^[A-Za-z]{3,25}$");
		matcher = pattern.matcher(p.getProductname());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Product Name!!!!");
		}

		// Phone Number Validation
		//if (donor.getPhoneNumber() <= 999999999) {
			//errorList.add("Please enter a valid Phone Number");
		//}
		
		
		//Product Description Validation!
		pattern = Pattern.compile("^[A-Z]{3,25}$");
		matcher = pattern.matcher(p.getProductdesc());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Product Description!!!!");
		}

		// Address Validation
		//pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
		//matcher = pattern.matcher(donor.getAddress());
		//if (!matcher.matches()) {
			//errorList.add("Please enter a valid Address");
		//}

		// Amount Validation
		//if (donor.getAmount() <= 0) {
			//errorList.add("Please enter a valid Amount");
		//}
		//return errorList;
		
		pattern = Pattern.compile("^[1-9]{2}$");
		matcher = pattern.matcher(p.getProductname());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Product Quantity!!!!");
		}
		
		pattern = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
		matcher = pattern.matcher(p.getProductname());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Product Date!!!!!!!");
		}
		return errorList;
	}
	
	
	
	
	
	

}
