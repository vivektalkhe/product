package com.cg.productmanagement.dao;


import java.sql.SQLException;
import java.util.List;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exception.ProductException;


public interface IProductDao {
	public int addProduct(Product p) throws ProductException, SQLException;

	public List<Product> showAll() throws ProductException;
	
	public Product getProduct(int productid);
	
	boolean updateQty(int productid, String productname, String productdesc, int productqty, int productprice) throws ProductException; 
	
	int deleteProduct (int productId) throws ProductException;

}
