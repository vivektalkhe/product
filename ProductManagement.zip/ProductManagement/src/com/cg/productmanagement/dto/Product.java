package com.cg.productmanagement.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Product {
	private int productid;
	private String productname;
	private String productdesc;
	private int productqty;
	private int productprice;
	private Date productdate;

	public Product() {
		super();
	}

	public Product(int productid, String productname, String productdesc,
			int productqty, int productprice, Date productdate) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productdesc = productdesc;
		this.productqty = productqty;
		this.productprice = productprice;
		this.productdate = productdate;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProductdesc() {
		return productdesc;
	}

	public void setProductdesc(String productdesc) {
		this.productdesc = productdesc;
	}

	public int getProductqty() {
		return productqty;
	}

	public void setProductqty(int productqty) {
		this.productqty = productqty;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	public Date getProductdate() {
		return productdate;
	}

	public void setProductdate(Date productdate) {
		this.productdate = productdate;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname="
				+ productname + ", productdesc=" + productdesc
				+ ", productqty=" + productqty + ", productprice="
				+ productprice + ", productdate=" + productdate + "]";
	}

}
