package com.cg.appl.dao;

import com.cg.appl.dto.Users;
import com.cg.appl.exceptions.UsersException;

public interface UsersDao {
	
	
	int addUser(Users user) throws UsersException;

}
