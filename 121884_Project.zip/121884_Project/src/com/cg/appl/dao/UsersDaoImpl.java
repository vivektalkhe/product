package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.dto.Users;
import com.cg.appl.exceptions.UsersException;
import com.cg.appl.util.JndiUtil;



public class UsersDaoImpl implements UsersDao {
	
	private JndiUtil util;
	
	

	public UsersDaoImpl() throws UsersException {
		try {
			util=new JndiUtil();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int addUser(Users user) throws UsersException {

		
		Connection connect=null;
		PreparedStatement stmt=null;
		int status=0;
		String msg;
		//
		String query="INSERT INTO USERS VALUES(?,?,?,?)";
		try {
			connect=util.getConnection();
			stmt=connect.prepareStatement(query);
			stmt.setString(1, user.getName());
			stmt.setString(2, user.getUserName());
			stmt.setString(3, user.getPassWord());
			stmt.setString(4, user.getPhoneNumber());
			status=stmt.executeUpdate();
			if(status==1)
			{
				System.out.println("Record is inserted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
		if(stmt!=null)
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(connect!=null)
			try {
				connect.close();
			} catch (SQLException e) {
				throw new UsersException("Connection Closing Failed");
			}
		}
		return status;
	}
}
