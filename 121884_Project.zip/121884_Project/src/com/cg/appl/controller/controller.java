/*********************************************************************
 * File                 : Controller.java
 * Author Name          : Vivek Talkhe
 * Desc                 : JAVA servlet(controller) which manages the flow of control throughout the application life cycle.
 *                        separates the presentation and the business logic.
 * Version              : 1.0
 * Creation Date        : 25-Mar-2017
 * Last Modified Date   : 25-Mar-2017
 *********************************************************************/

package com.cg.appl.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.dto.Users;
import com.cg.appl.exceptions.UsersException;
import com.cg.appl.service.UsersService;
import com.cg.appl.service.UsersServiceImpl;

@WebServlet("*.do")
public class controller extends HttpServlet {

	private static final long serialVersionUID = 1L;

	UsersService service;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
	

	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getServletPath();
		System.out.println(path);
		service=new UsersServiceImpl();
		if (path.equals("/register.do")) {
			
			RequestDispatcher res = request.getRequestDispatcher("register.jsp");
			res.forward(request, response);
		
		}
		
		if(path.equals("/customerHome.do"))
		{
			Users user=new Users();
			String uname = request.getParameter("nm");
			String pnumber = request.getParameter("phnumber");
			String username = request.getParameter("uname");
			String userpass = request.getParameter("upass");
			String reEnterpass = request.getParameter("repass");
			user.setName(uname);
			user.setPhoneNumber(pnumber);
			user.setUserName(username);
			user.setPassWord(userpass);
			user.setPassWord(reEnterpass);
				try {
					int Id = service.addUser(user);
					System.out.println("Method in controller");
					
					request.setAttribute("id", username);
					RequestDispatcher req = request.getRequestDispatcher("customerHome.jsp");
					request.setAttribute("pNumber", pnumber);
					
					req.forward(request, response);
				} catch (UsersException e) {
					// TODO Auto-generated catch block
					RequestDispatcher req = request.getRequestDispatcher("error.jsp");
					request.setAttribute("error",e);
				}
			} 
		if(path.equals("/payBill.do"))
			{
			/*LocalDate bdate;
			java.util.Date d=new java.util.Date();
			bdate new Date(x.getTime());*/
			String amt = request.getParameter("amt");
			double amount=750;
			double userAmount = Double.parseDouble(amt);
			double balanceAmount = amount - userAmount;
			RequestDispatcher req = request.getRequestDispatcher("success.jsp");
			request.setAttribute("bal", balanceAmount);
			req.forward(request, response);
			}
	/*	if(path.equals("/success.do"))
		{			
			RequestDispatcher req = request.getRequestDispatcher("success.jsp");
			String amt = request.getParameter("amt");
			double amount=750;
			double userAmount = Double.parseDouble(amt);
			double balanceAmount = amount - userAmount;
			request.setAttribute("bal", balanceAmount);
			req.forward(request, response);
	}*/
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}
}
