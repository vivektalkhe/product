package com.cg.appl.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.appl.dao.UsersDao;
import com.cg.appl.dao.UsersDaoImpl;
import com.cg.appl.dto.Users;
import com.cg.appl.exceptions.UsersException;


public class UsersServiceImpl implements UsersService {
	
	UsersDao dao;

	public UsersServiceImpl()  {
			try {
				dao=new UsersDaoImpl();
			} catch (UsersException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Override
	public int addUser(Users user) throws UsersException {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}



	public List<String> isValidated(Users user) {

		List<String> errorList = new ArrayList<String>();

		Pattern pattern = null;
		Matcher matcher = null;

		// UserName Validation
		pattern = Pattern.compile("^[A-Za-z]{3,40}$");
		matcher = pattern.matcher(user.getUserName());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid User Name!!!!");
		}
		
		//Password Validation!
				pattern = Pattern.compile("^[A-Z]{3,25}$");//("(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")"Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters
				matcher = pattern.matcher(user.getPassWord());
				if (!matcher.matches()) {
					errorList.add("Please enter a valid Password!!!!");
				}
				
		//Phone Number Validation!
				pattern = Pattern.compile("^[7-9]{1}[0-9]{9}$");		//^\d{4}-\d{3}-\d{4}$
				matcher = pattern.matcher(user.getPhoneNumber());
				if (!matcher.matches()) {
					errorList.add("Please enter a valid Phone Number!!!!");
				}
		return errorList;
	}

}
