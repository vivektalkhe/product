package com.cg.appl.service;

import com.cg.appl.dto.Users;
import com.cg.appl.exceptions.UsersException;



public interface UsersService {
	
	int addUser(Users user) throws UsersException;

}
