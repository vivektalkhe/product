package com.cg.appl.dto;

import java.io.Serializable;

public class Users implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String userName;
	private String passWord;
	private String phoneNumber;
	
	public Users() {
		// TODO Auto-generated constructor stub
	}

	public Users(String name, String userName, String passWord, String phoneNumber) {
		super();
		this.name = name;
		this.userName = userName;
		this.passWord = passWord;
		this.phoneNumber = phoneNumber;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getPassWord() {
		return passWord;
	}



	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}



	public String getPhoneNumber() {
		return phoneNumber;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Users [name=" + name + ", userName=" + userName + ", passWord=" + passWord + ", phoneNumber="
				+ phoneNumber + "]";
	}
}
