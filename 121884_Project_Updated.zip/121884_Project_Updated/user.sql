CREATE TABLE users(name VARCHAR2(40), user_name VARCHAR2(40) PRIMARY KEY, password VARCHAR2(15), mobile_number VARCHAR2(12));

select * from users;