package com.cg.electricity.dto;

public class Consumers {
	private int consumerno;
	private String consumername;
	private String address;

	public Consumers() {
		super();
	}

	public Consumers(int consumerno, String consumername, String address) {
		super();
		this.consumerno = consumerno;
		this.consumername = consumername;
		this.address = address;
	}

	public int getConsumerno() {
		return consumerno;
	}

	public void setConsumerno(int consumerno) {
		this.consumerno = consumerno;
	}

	public String getConsumername() {
		return consumername;
	}

	public void setConsumername(String consumername) {
		this.consumername = consumername;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Consumers [consumerno=" + consumerno + ", consumername="
				+ consumername + ", address=" + address + "]";
	}

}
