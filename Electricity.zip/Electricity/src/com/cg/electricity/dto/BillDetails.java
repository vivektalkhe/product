package com.cg.electricity.dto;

import java.sql.Date;

public class BillDetails {

	private int billnumber;
	private int consumerno;
	private int currentreading;
	private int unitconsumed;
	private int netamount;
	private Date billdate;

	public BillDetails() {
		super();
	}

	public BillDetails(int billnumber, int consumerno, int currentreading,
			int unitconsumed, int netamount, Date billdate) {
		super();
		this.billnumber = billnumber;
		this.consumerno = consumerno;
		this.currentreading = currentreading;
		this.unitconsumed = unitconsumed;
		this.netamount = netamount;
		this.billdate = billdate;
	}

	public int getBillnumber() {
		return billnumber;
	}

	public void setBillnumber(int billnumber) {
		this.billnumber = billnumber;
	}

	public int getConsumerno() {
		return consumerno;
	}

	public void setConsumerno(int consumerno) {
		this.consumerno = consumerno;
	}

	public int getCurrentreading() {
		return currentreading;
	}

	public void setCurrentreading(int currentreading) {
		this.currentreading = currentreading;
	}

	public int getUnitconsumed() {
		return unitconsumed;
	}

	public void setUnitconsumed(int unitconsumed) {
		this.unitconsumed = unitconsumed;
	}

	public int getNetamount() {
		return netamount;
	}

	public void setNetamount(int netamount) {
		this.netamount = netamount;
	}

	public Date getBilldate() {
		return billdate;
	}

	public void setBilldate(Date billdate) {
		this.billdate = billdate;
	}

	@Override
	public String toString() {
		return "BillDetails [billnumber=" + billnumber + ", consumerno="
				+ consumerno + ", currentreading=" + currentreading
				+ ", unitconsumed=" + unitconsumed + ", netamount=" + netamount
				+ ", billdate=" + billdate + "]";
	}

}
