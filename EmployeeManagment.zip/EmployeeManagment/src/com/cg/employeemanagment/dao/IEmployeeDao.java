package com.cg.employeemanagment.dao;

import java.util.List;

import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.exception.EmployeeException;

public interface IEmployeeDao {
	
	public int addDataEmployee(Employee emp) throws EmployeeException;
	public List<Employee> showAllData() throws EmployeeException;
	public Employee searchData(int empId) throws EmployeeException;
	public void reamoveData(int empId);

}
