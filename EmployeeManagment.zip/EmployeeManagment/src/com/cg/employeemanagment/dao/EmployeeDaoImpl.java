package com.cg.employeemanagment.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.exception.EmployeeException;
import com.cg.employeemanagment.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
Connection conn=null;
PreparedStatement pstm=null;
private static final Logger mylogger=
Logger.getLogger(EmployeeDaoImpl.class);
	
	@Override
	public int addDataEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		int empId=0;
		int eId=0;
		
String query="INSERT INTO EMPLOYEEONE VALUES(?,?,?,?)";
try {
	eId=getEmployeeId();
	conn=DbUtil.getConnection();
	pstm=conn.prepareStatement(query);
	pstm.setInt(1,eId);
	pstm.setString(2,emp.getEmpName());
	pstm.setString(3,emp.getEmpDepartment());
	pstm.setDouble(4,emp.getEmpSalary());
	
	int status=pstm.executeUpdate();
	if(status==1){
		mylogger.info("Employee Id is "+eId);
		empId=eId;
	}
} catch (EmployeeException | SQLException e) {
	// TODO Auto-generated catch block
	//e.printStackTrace();
	mylogger.error(" Data Not inserted "+e.getMessage());
	throw new EmployeeException("Data Not Inserted..");
}finally{
	try {
		pstm.close();
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
return empId;
	}

	@Override
	public List<Employee> showAllData() throws EmployeeException {
		// TODO Auto-generated method stub
		List<Employee> myList=new ArrayList<Employee>();
String query="SELECT emp_id,emp_name,emp_dep,"
				+ "emp_sal FROM EMPLOYEEONE";			
try {
	conn=DbUtil.getConnection();
	pstm=conn.prepareStatement(query);
	ResultSet res=pstm.executeQuery();
	while(res.next()){
		Employee empo=new Employee();
		empo.setEmpId(res.getInt("emp_id"));
		empo.setEmpName(res.getString("emp_name"));
		empo.setEmpDepartment(res.getString("emp_dep"));
		empo.setEmpSalary(res.getDouble("emp_sal"));
		myList.add(empo);
	}
} catch (EmployeeException | SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	throw new EmployeeException("Data not Displayed");
}finally{
	try {
		pstm.close();
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
		return myList;
	}

	@Override
	public Employee searchData(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		Connection conn=null;
		PreparedStatement pstm=null;
		Employee empSerach=new Employee();
String query="SELECT emp_id,emp_name,emp_dep,emp_sal FROM EMPLOYEEONE WHERE emp_id=?";
		try {
			conn=DbUtil.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,empId);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				empSerach.setEmpId(res.getInt("emp_id"));
				empSerach.setEmpName(res.getString("emp_name"));
				empSerach.setEmpDepartment(res.getString("emp_dep"));
				empSerach.setEmpSalary(res.getDouble("emp_sal"));
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Data Not found");
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return empSerach;
	}

	@Override
	public void reamoveData(int empId) {
		// TODO Auto-generated method stub
		
	}
	
	public static int getEmployeeId(){
		int id=0;
		String query="SELECT emp__data_id.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement pstm=null;
		
		try {
			conn=DbUtil.getConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
			
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return id;
		
	}

}
