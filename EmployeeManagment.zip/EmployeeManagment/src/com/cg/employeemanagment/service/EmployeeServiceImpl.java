package com.cg.employeemanagment.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemanagment.dao.EmployeeDaoImpl;
import com.cg.employeemanagment.dao.IEmployeeDao;
import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService  {
IEmployeeDao employeeDao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		
		return employeeDao.addDataEmployee(emp);
	}

	@Override
	public List<Employee> showAll()throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.showAllData();
	}

	@Override
	public Employee searchEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.searchData(empId);
	}

	@Override
	public void removeEmployee(int empId) {
		// TODO Auto-generated method stub
		employeeDao.reamoveData(empId);
	}
	
	public static void validateName
	(String patt,String name) throws EmployeeException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new EmployeeException("Name should be min3 max 10 First letter capital");
	}
		
	}

	

}
